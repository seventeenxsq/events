package listener;

/**
 * 网路数据接口
 */
public interface Service {

    //用于展示列表数据
    String first_url="http://www.mingrisoft.com/Index/API/getAllCourse/rows/7";
    //获取页面详情
    String second_url="http://www.mingrisoft.com/Index/API/getSystemCourseInfo/course_id/"+"%s"+"/user_id/"+"%s";
}
