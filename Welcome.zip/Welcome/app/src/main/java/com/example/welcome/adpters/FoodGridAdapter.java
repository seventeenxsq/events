package com.example.welcome.adpters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.example.welcome.R;

public class FoodGridAdapter extends RecyclerView.Adapter<FoodGridAdapter.ViewHolder> {

    private  Context mContext;
    public  FoodGridAdapter(Context context){
            mContext=context;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_grid_music,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

        Glide.with(mContext)
                .load("http://img.pconline.com.cn/images/upload/upc/tx/photoblog/1610/07/c7/28013423_1475810817714_mthumb.jpg")
                .into(viewHolder.ivIcon);

    }

    @Override
    public int getItemCount() {
        return 6;
    }

    class ViewHolder extends  RecyclerView.ViewHolder{

        ImageView ivIcon;
        public  ViewHolder (@NonNull View itemView){
            super((itemView));

            ivIcon=itemView.findViewById(R.id.iv_icon);
        }
    }
}
