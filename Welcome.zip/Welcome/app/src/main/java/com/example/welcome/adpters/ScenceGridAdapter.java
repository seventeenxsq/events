package com.example.welcome.adpters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.welcome.R;

public class ScenceGridAdapter extends RecyclerView.Adapter<ScenceGridAdapter.ViewHolder>{

    private Context mContext;
    public  ScenceGridAdapter(Context context){
        mContext=context;
    }
    @NonNull
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ScenceGridAdapter.ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_grid_meishi,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

    }


    @Override
    public int getItemCount() {
        return 6;
    }

    class ViewHolder extends  RecyclerView.ViewHolder{
        public  ViewHolder(@NonNull View itemView){
            super((itemView));
        }
    }
}


