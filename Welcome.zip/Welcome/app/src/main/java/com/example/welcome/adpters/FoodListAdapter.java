package com.example.welcome.adpters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.example.welcome.R;

public class FoodListAdapter extends RecyclerView.Adapter<FoodListAdapter.ViewHolder> {

    private Context mContext;
    private RecyclerView mRv;
    private  View mItemView;
    private boolean isCalcaulationRvHeight;

    public  FoodListAdapter(Context context,RecyclerView recyclerView){
        mContext=context;
        mRv=recyclerView;
    }//接受上下文

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        mItemView=LayoutInflater.from(mContext).inflate(R.layout.item_list_food,viewGroup,false);
        return new ViewHolder(mItemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
            setRecycleViewHeight();

            Glide.with(mContext)
                    .load("http://img.pconline.com.cn/images/upload/upc/tx/itbbs/1609/10/c18/26799268_1473492338587_mthumb.jpg")
                    .into(viewHolder.ivIcon);

    }

    @Override
    public int getItemCount() {
        return 8;
    }


    /**
     * 使用 itemheighr*itemNUm=RecycleVirw的高度
     */
    private  void setRecycleViewHeight(){
        if (isCalcaulationRvHeight||mRv==null) return;
        isCalcaulationRvHeight=true;
        //获取Item View的高度
       RecyclerView.LayoutParams itemViewLp= (RecyclerView.LayoutParams) mItemView.getLayoutParams();
       //获取itemView的数量
        int itemCount=getItemCount();
        //代入公式
          int recycleViewHeight=itemViewLp.height * itemCount;
         //设置Recycle View高度
        LinearLayout.LayoutParams rvLp = (LinearLayout.LayoutParams) mRv.getLayoutParams();
        rvLp.height=recycleViewHeight;
                mRv.setLayoutParams(rvLp);
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        ImageView ivIcon;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon=itemView.findViewById(R.id.iv_icon1);
        }
    }
}
