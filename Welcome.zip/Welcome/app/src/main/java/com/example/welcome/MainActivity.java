package com.example.welcome;

import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.welcome.adpters.FoodGridAdapter;
import com.example.welcome.adpters.FoodListAdapter;
import com.example.welcome.adpters.ScenceGridAdapter;
import com.example.welcome.views.GridSpaceItemDecoration;

public class MainActivity extends BaseActivity {

        private RecyclerView mRvGrid,mRvList,mRvGrid2;
        private FoodGridAdapter mAdapter;
       private FoodListAdapter mListAdapter;
       private ScenceGridAdapter mMeishiSdapter;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
           initView();
        }
        private void initView(){
            initNavBar(false,"徽畅游",true);

            mRvGrid=fd(R.id.ry_grid);
            mRvGrid.addItemDecoration(new GridSpaceItemDecoration(getResources().getDimensionPixelSize(R.dimen.pictureMarginSize)));
            mRvGrid.setLayoutManager(new GridLayoutManager(this,3));
            mAdapter=new FoodGridAdapter(this);
            mRvGrid.setAdapter(mAdapter);


            mRvList=fd(R.id.rv_list);
            mRvList.setLayoutManager(new LinearLayoutManager(this));
            mRvList.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));
            mListAdapter=new FoodListAdapter(this,mRvList);
            mRvList.setNestedScrollingEnabled(false);
            mRvList.setAdapter(mListAdapter);

            mRvGrid2=fd(R.id.ry_scence);
            mRvGrid2.addItemDecoration(new GridSpaceItemDecoration(getResources().getDimensionPixelSize(R.dimen.pictureMarginSize)));
            mRvGrid2.setLayoutManager(new GridLayoutManager(this,3));
            mMeishiSdapter=new ScenceGridAdapter(this);
            mRvGrid2.setNestedScrollingEnabled(false);
            mRvGrid2.setAdapter(mMeishiSdapter);


        }


    }

